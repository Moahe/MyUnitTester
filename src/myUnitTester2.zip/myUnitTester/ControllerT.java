/**
 * Application development in Java, 5dv135-apjava-ht17,
 * Assignment 1: MyUnitTester,
 * 
 * 
 * Last Edited: 2017-11-13
 * @author Moa Hermansson, id14mhn
 */

package myUnitTester;

import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

import java.lang.reflect.*;

/**
 * The Controller extends SwingWorker and is connected
 * to the Swing GUI. It creates a new thread and 
 * tests the input test given by user into the textfield
 * in the interface. It uses the class ModelT to check the
 * input class. It adds the result given from ModelT and
 * prints it out in the textArea in the interface. 
 * 
 * It retrieves the amounts of fail/fail by exception/success
 * by the model and prints it.
 * 
 * If the classChecker checks the class as incorrect a 
 * "incorrect class" will be printed instead.
 * 
 *
 */
@SuppressWarnings("rawtypes")
public class ControllerT extends SwingWorker{
	private JTextArea textArea;
	private JTextField textField;
	String testToTest = "";
	String result = " ";
	String methodname = "";

	ControllerT(JTextArea textArea, JTextField textField){
		this.textArea = textArea;
		this.textField = textField;
	}

	@Override
	protected Object doInBackground() throws ClassNotFoundException, IllegalAccessException, InstantiationException,
	NoSuchMethodException, InvocationTargetException, InterruptedException
	{
		/* Retrieves the getText from interface. */
		testToTest = textField.getText();
		Class<?> c = null;
		ModelT classChecker = new ModelT();
		
		/* Tries to create a class from the input. If user
		 * has given an incorrect input a "Incorrect input of class"
		 * will be printed to the interface */
		try{
			c = Class.forName("myUnitTester."+testToTest);

		}catch(Exception e){
			result="Incorrect input of class\n\n";
		}
		
		
		classChecker.sortMethodsInClass(c);

		if(classChecker.getIncorrectClass()==false){
			try {
				classChecker.runTestMethods();
				result = classChecker.getResult()+"\n";
				result += " "+classChecker.getNumberOfSuccessTest()+" tests succeded\n "+classChecker.getNumberOfFailedTest()+" tests failed\n "
						+classChecker.getNumberOfExceptionTest()+" tests failed because of an exception\n\n";
	
			} catch (InstantiationException|IllegalAccessException|IllegalArgumentException|InvocationTargetException e) {
				result+="Threw Exception: "+e.getCause();
			}
		}
		else{result=" Incorrect class, Needs to implement TestClass and \nhave a constructor with no parameters.\n\n";}
		
		return result;

	}
	@Override
	protected void done(){
		try{
			/* When the method doInBackground() is finished it will try to append the result
			 * to the textArea in the interface. */
			
			textArea.append(result);
			textField.selectAll();
			textArea.setCaretPosition(textArea.getDocument().getLength());
		} catch(Exception ignore){

		}
	}

}
