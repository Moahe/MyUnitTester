/**
 * Application development in Java, 5dv135-apjava-ht17,
 * Assignment 1: MyUnitTester,
 * 
 * 
 * Last Edited: 2017-11-13
 * @author Moa Hermansson, id14mhn
 */
package myUnitTester;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Creates a GUI with java.swing and adds a textField,
 * textArea and two buttons. One for clearing the textArea
 * and one for testing the input in the textField.
 * 
 */
@SuppressWarnings("serial")
public class ViewT extends JPanel{
	protected JTextField textField;
	protected JTextArea textArea;
	protected JButton testButton;
	protected JButton clearButton;

	public ViewT() {
		super(new GridBagLayout());
		
		//Creates components
		textField = new JTextField(20);
		textArea = new JTextArea(30, 40);
		testButton = new JButton("Test");
		clearButton = new JButton("Clear");
		
		/*Adds the ActionListeners to the buttons and fields.*/
		testButton.addActionListener(new TextListener(textArea, textField));
		textField.addActionListener(new TextListener(textArea, textField));
		clearButton.addActionListener(new ButtonListener(textArea));

		textArea.setEditable(false);

		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		add(testButton);

		GridBagConstraints c = new GridBagConstraints();
	
		c.gridwidth = GridBagConstraints.REMAINDER;

		c.fill = GridBagConstraints.HORIZONTAL;
		add(textField, c);

		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1.0;
		c.weighty = 1.0;

		add(scrollPane, c);
		add(clearButton);

	}
	
	/**
	 * Makes the interface created in ViewTest visible. 
	 */
	public void showInterface() {
		JFrame frame = new JFrame("MyUnitTester");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.add(new ViewT());
		frame.pack();
		frame.setVisible(true);
	}

}


/**
 * TextListener gets called by 
 * the testButton and by clicking
 * enter in the textField. It Appends text
 * to the textArea in the
 * interface. 
 * 
 *
 */
class TextListener implements ActionListener{
	private JTextArea textArea;
	private JTextField textField;


	public TextListener(JTextArea textArea, JTextField textField){
		this.textArea = textArea;
		this.textField = textField;
	}

	public void actionPerformed(ActionEvent evt) {

		ControllerT wtest = new ControllerT(textArea, textField);

		try{
			appendText("Testing: "+textField.getText()+"\n");
			if(textField.getText().isEmpty()){
				appendText("No class given, Write in field \n what class you want to test.\n");
			}
			else{
			wtest.execute();
			}
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	public void appendText(String text){

		textArea.append(text + "\n");
		textField.selectAll();
		textArea.setCaretPosition(textArea.getDocument().getLength());

	}

}


/**
 * The ButtonListener is connected to
 * the clearButton in the interface. 
 * It clears the textArea of text.
 * 
 */
class ButtonListener implements ActionListener {
	private JTextArea textArea;

	public ButtonListener(JTextArea textArea){
		this.textArea = textArea;
	}

	public void actionPerformed(ActionEvent e) {
		textArea.setText(null);

	}

}
