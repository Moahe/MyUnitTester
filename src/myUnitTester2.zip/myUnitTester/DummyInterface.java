package myUnitTester;


public interface DummyInterface {
    public void doNothing();
}
