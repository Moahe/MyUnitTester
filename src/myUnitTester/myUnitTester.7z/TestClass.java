package myUnitTester;

public interface TestClass {

}
