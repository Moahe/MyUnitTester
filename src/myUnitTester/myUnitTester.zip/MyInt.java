package myUnitTester;

public class MyInt {
	private int val;
	public MyInt() {
		val=0;
	}
	
	public void increment() {
		val++;
	}
	
	public void decrement() {
		val--;
	}
	
	public int value() {
		return val;
	}

}
